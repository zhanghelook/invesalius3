"""PyQt v4 widget for VTK."""

__all__ = ['QVTKRenderWindowInteractor']
