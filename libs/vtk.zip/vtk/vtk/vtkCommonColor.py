from vtkCommonColorPython import *
