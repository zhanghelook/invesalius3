from vtkCommonComputationalGeometryPython import *
