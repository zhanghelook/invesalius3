from vtkCommonCorePython import *
