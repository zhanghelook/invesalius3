from vtkCommonDataModelPython import *
