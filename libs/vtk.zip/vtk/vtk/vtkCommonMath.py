from vtkCommonMathPython import *
