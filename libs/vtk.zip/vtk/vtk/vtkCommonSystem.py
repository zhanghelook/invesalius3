from vtkCommonSystemPython import *
