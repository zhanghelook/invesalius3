from vtkFiltersAMRPython import *
