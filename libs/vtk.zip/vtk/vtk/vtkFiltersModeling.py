from vtkFiltersModelingPython import *
