from vtkFiltersStatisticsPython import *
