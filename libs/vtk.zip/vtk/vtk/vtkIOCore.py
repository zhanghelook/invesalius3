from vtkIOCorePython import *
