from vtkIOGeometryPython import *
