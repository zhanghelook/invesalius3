from vtkIOImagePython import *
