from vtkIOInfovisPython import *
