from vtkIOLegacyPython import *
