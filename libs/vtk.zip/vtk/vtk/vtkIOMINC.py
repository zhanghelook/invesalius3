from vtkIOMINCPython import *
