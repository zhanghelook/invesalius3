from vtkIOPLYPython import *
