from vtkImagingColorPython import *
