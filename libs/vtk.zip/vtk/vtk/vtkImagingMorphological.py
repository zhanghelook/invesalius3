from vtkImagingMorphologicalPython import *
