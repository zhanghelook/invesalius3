from vtkImagingStatisticsPython import *
