from vtkImagingStencilPython import *
