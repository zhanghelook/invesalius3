from vtkInfovisCorePython import *
