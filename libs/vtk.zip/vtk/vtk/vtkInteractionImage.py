from vtkInteractionImagePython import *
