from vtkViewsInfovisPython import *
